 document.addEventListener("DOMContentLoaded", function () {
        let verifyContain = document.querySelector(".verifyContain");
        let activeStep = parseInt(verifyContain.getAttribute("data-active"));
        let steps = document.querySelectorAll(".step");
        let lines = document.querySelectorAll(".line");

        // Apply active styles based on the set value
        for (let i = 0; i < activeStep; i++) {
            steps[i].classList.add("active");
            if (i > 0) lines[i - 1].classList.add("active-line");
        }
    });